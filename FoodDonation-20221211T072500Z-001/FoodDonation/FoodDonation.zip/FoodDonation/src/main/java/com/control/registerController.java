package com.control;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.been.RegisterBeen;
import com.dao.registerDao;

@WebServlet("/registerController")
@MultipartConfig(maxFileSize = 16177216)
public class registerController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String action = request.getParameter("action");
		String error = " ";

		if (action.equalsIgnoreCase("register")) {
			RegisterBeen reg = new RegisterBeen();

			reg.setFirst_name(request.getParameter("fname"));
			reg.setMiddle_name(request.getParameter("mname"));
			reg.setLast_name(request.getParameter("lname"));
			reg.setEmail(request.getParameter("email"));
			reg.setPassword(request.getParameter("pass"));
			reg.setPhone_number(request.getParameter("phonenumber"));
			reg.setDob(request.getParameter("dob"));
			reg.setGender(request.getParameter("gender"));
			reg.setIs_donor(request.getParameter("donor"));
			reg.setAddress(request.getParameter("address"));
			reg.setCity(request.getParameter("city"));
			reg.setState(request.getParameter("state"));
			reg.setPincode(Integer.parseInt(request.getParameter("pincode")));
			reg.setAadhar_no(request.getParameter("aadherno"));
			Part filePart = request.getPart("image");
			if (filePart != null) {
				InputStream img = filePart.getInputStream();
				reg.setUimage(img);
				int register = registerDao.insertregister(reg);
				if (register > 0) {
					RegisterBeen log = new RegisterBeen();
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Registered Successfully');");
					out.println("</script>");
					request.getRequestDispatcher("Login.jsp").forward(request, response);
				} else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Registration Fail Something Wrong');");
					out.println("</script>");
					RequestDispatcher rd = request.getRequestDispatcher("Registration.jsp");
					rd.include(request, response);
				}
			}

		}
		if (action.equalsIgnoreCase("login")) {
			RegisterBeen reg = new RegisterBeen();

			reg.setEmail(request.getParameter("email"));
			reg.setPassword(request.getParameter("pass"));

			RegisterBeen in = registerDao.login(reg);
			boolean flag = registerDao.checkemail(request.getParameter("email"));
			if (flag == false) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('email id is not valid please register');");
				out.println("</script>");
				RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
				rd.include(request, response);
			} else {
				if (!request.getParameter("email").equalsIgnoreCase("")
						|| request.getParameter("pass").equalsIgnoreCase("")) {
					if (in != null) {
						HttpSession session = request.getSession();
						session.setAttribute("in", in);
						request.getRequestDispatcher("index.jsp").forward(request, response);
					} else {
						// error="your email or password is incorrect";
						out.println("<script type=\"text/javascript\">");
						out.println("alert('your email or password is incorrect');");
						out.println("</script>");
						RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
						rd.include(request, response);
						// request.getRequestDispatcher("login.jsp").forward(request,response);
					}
				}
			}
		}
		if(action.equalsIgnoreCase("log"))
		{
			RegisterBeen u=new RegisterBeen();
			u.setEmail(request.getParameter("email"));
			u.setPassword(request.getParameter("pass"));
			RegisterBeen in=registerDao.log(u);
			boolean flag=registerDao.checkemail(request.getParameter("email"));
			if(flag==false){
				out.println("<script type=\"text/javascript\">");
				out.println("alert('email id is not valid please register');");
				out.println("</script>");
				RequestDispatcher rd=request.getRequestDispatcher("register.jsp");
				rd.include(request, response);
				
			}
			else {
				if(!request.getParameter("email").equalsIgnoreCase("") || request.getParameter("password").equalsIgnoreCase(""))
				{
					if(in!=null)
					{
						HttpSession session=request.getSession();
						session.setAttribute("in",in);
						request.getRequestDispatcher("index.jsp").forward(request, response);
					}
					else
					{
						//error="your email or password is incorrect";
						out.println("<script type=\"text/javascript\">");
						out.println("alert('your email or password is incorrect');");
						out.println("</script>");
						RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
						rd.include(request, response);
						//request.getRequestDispatcher("login.jsp").forward(request,response);
					}
				}
			}
		}
		
		
		
		
		
		
		

	}

}
