package com.process;

import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class mailsend {
	
	public static void Mailsend(String from,String password,String message,String to,String subject) 
	{
		
		
		String host="smtp.gmail.com";
		String port="465";
		
		Properties prop=System.getProperties();
		prop.put("mail.smtp.starttls.enable", "true");
		prop.put("mail.smtp.host", host);
		prop.put("mail.smtp.auth","true");
		prop.put("mail.smtp.user", from);
		prop.put("mail.smtp.password",password);
		prop.put("mail.smtp.port",port);
		prop.put("mail.smtp.socketFactory.port", port);
		prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		prop.put("mail.smtp.socketFactory.fallback", "false");
		Session session=Session.getDefaultInstance(prop, null);
		session.setDebug(true);
		MimeMessage mimeMessage=new MimeMessage(session);
		try{
		mimeMessage.setFrom(new InternetAddress(from));
		//Now Get The Address Of Reciepents
		InternetAddress toAddresses=new InternetAddress();
		
			toAddresses=new InternetAddress(to);
		
		//Now add all toAddress elements 
		//mimeMessage
		
			mimeMessage.addRecipient(RecipientType.TO, toAddresses);
		
		//add Subject TO mimeMessage
		mimeMessage.setSubject("otp verification");
		//Set Message TO mimeMessage
		mimeMessage.setText(message);
		Transport transport=session.getTransport("smtp");
		transport.connect(host,from,password);
		transport.sendMessage(mimeMessage,mimeMessage.getAllRecipients());
		transport.close();
	
		}
		catch(MessagingException me){
			me.printStackTrace();
		}
		
	
	 }
}
