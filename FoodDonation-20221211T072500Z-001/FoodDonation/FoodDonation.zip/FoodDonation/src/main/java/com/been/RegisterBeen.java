package com.been;

import java.io.InputStream;

public class RegisterBeen {
	protected int uid;
	protected String email;
	protected String first_name;
	protected String middle_name;
	protected String last_name;
	protected String password;
	protected String phone_number; 
	protected String is_donor;
	protected String address;	
	protected String dob;
	protected String gender;
	protected int pincode;
	protected String city;
	protected String state;
	protected String aadhar_no;
	InputStream uimage;
	
	public RegisterBeen() {
		
	}

public RegisterBeen(int uid) {
		this.uid=uid;
	}
	 


	public int getUid() {
		return uid;
	}





	public void setUid(int uid) {
		this.uid = uid;
	}





	public InputStream getUimage() {
		return uimage;
	}





	public void setUimage(InputStream uimage) {
		this.uimage = uimage;
	}





	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getMiddle_name() {
		return middle_name;
	}

	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getIs_donor() {
		return is_donor;
	}

	public void setIs_donor(String is_donor) {
		this.is_donor = is_donor;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAadhar_no() {
		return aadhar_no;
	}

	public void setAadhar_no(String aadhar_no) {
		this.aadhar_no = aadhar_no;
	}
	
	
	
	
}
