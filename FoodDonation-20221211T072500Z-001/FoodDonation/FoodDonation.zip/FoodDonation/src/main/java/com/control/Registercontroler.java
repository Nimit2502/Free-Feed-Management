package com.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.been.RegisterBeen;
import com.dao.Logindao;



/**
 * Servlet implementation class Registercontroler
 */
@WebServlet("/Registercontroler")
public class Registercontroler extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String action=request.getParameter("action");
		String error=" ";
		
		if(action.equalsIgnoreCase("login"))
		{
			RegisterBeen u=new RegisterBeen();
			u.setEmail(request.getParameter("email"));
			u.setPassword(request.getParameter("pass"));
			RegisterBeen in=Logindao.login(u);
			boolean flag=Logindao.checkemail(request.getParameter("email"));
			if(flag==false){
				out.println("<script type=\"text/javascript\">");
				out.println("alert('email id is not valid');");
				out.println("</script>");
				RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
				rd.include(request, response);
				
			}
			else {
				if(!request.getParameter("email").equalsIgnoreCase("") || request.getParameter("pass").equalsIgnoreCase(""))
				{
					if(in!=null)
					{
						HttpSession session=request.getSession();
						session.setAttribute("in",in);
						request.getRequestDispatcher("index.jsp").forward(request, response);
					}
					else
					{
						//error="your email or password is incorrect";
						out.println("<script type=\"text/javascript\">");
						out.println("alert('your email or password is incorrect');");
						out.println("</script>");
						RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
						rd.include(request, response);
						//request.getRequestDispatcher("login.jsp").forward(request,response);
					}
				}
			}
		}
		
	// TODO Auto-generated method stub
	}

}
