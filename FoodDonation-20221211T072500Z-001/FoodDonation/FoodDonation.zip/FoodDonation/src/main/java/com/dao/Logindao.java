package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.been.RegisterBeen;
import com.dataconnn.datacon;

public class Logindao {
	public static boolean checkemail(String email)
	{
		boolean flag=false;
	    try {
			Connection con=datacon.getDatabaseconn();
			String sql="select * from user_mst_table where email=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,email);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				flag=true;
			}
			ps.executeUpdate();
		} 
	    catch (Exception e) {
	    	System.out.print("done");
			// TODO: handle exception
		}
		return flag;
	}
	
	
	
	public static RegisterBeen login(RegisterBeen u)
	{
		RegisterBeen in=null;
	    try {
			Connection con=datacon.getDatabaseconn();
			String sql="select * from user_mst_table where email=? and password=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,u.getEmail());
			ps.setString(2,u.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				in=new RegisterBeen();
				//in.setid(rs.getInt("id"));
				in.setEmail(rs.getString("email"));
				in.setPhone_number(rs.getString("phone_number"));
				in.setFirst_name(rs.getString("first_name"));
				in.setMiddle_name(rs.getString("middle_name"));
				in.setLast_name(rs.getString("last_name"));
				in.setIs_donor(rs.getString("is_donor"));
				in.setUid(rs.getInt("user_id")); 
				in.setGender(rs.getString("gender"));
				in.setAddress(rs.getString("address"));
				in.setCity(rs.getString("city"));
				in.setState(rs.getString("state"));
				in.setPincode(rs.getInt("pincode"));
				
			}
		} 
	    catch (Exception e) {
	    	System.out.print("Success");
			// TODO: handle exception
		}
		
		return in;
		
	}
	
	public static int updateuser(RegisterBeen been) {
		int result = 0;
		Connection con = datacon.getDatabaseconn();
		String sql = "update `user_mst_table` set first_name=?,middle_name = ?,last_name=?,email=?,phone_number = ?,gender=?,is_donor=?,address = ?,city=?,state=?,pincode= ? where user_id=?";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, been.getFirst_name());
			ps.setString(2,been.getMiddle_name());
			ps.setString(3,been.getLast_name());
			ps.setString(4, been.getEmail());
			ps.setString(5,been.getPhone_number());
			ps.setString(6,been.getGender());
			ps.setString(7,been.getIs_donor());
			ps.setString(8,been.getAddress());
			ps.setString(9,been.getCity());
			ps.setString(10,been.getState());
			ps.setInt(11,been.getPincode());
			ps.setInt(12, been.getUid());
			result = ps.executeUpdate();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

}
