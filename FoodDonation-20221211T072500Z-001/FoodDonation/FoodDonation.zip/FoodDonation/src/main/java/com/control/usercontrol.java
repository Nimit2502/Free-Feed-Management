package com.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.been.RegisterBeen;
import com.been.feedbeen;
import com.dao.Logindao;
import com.dao.basicdao;
import com.dataconnn.datacon;

@WebServlet("/usercontrol")
public class usercontrol extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String action = request.getParameter("action");
		String error = " ";
		if (action.equalsIgnoreCase("feedback")) {
			feedbeen feed_info=new feedbeen();
			feed_info.setName(request.getParameter("name"));
			feed_info.setEmail(request.getParameter("email"));
			feed_info.setComment(request.getParameter("comment"));
			feed_info.setRating(request.getParameter("rating"));
			
			int add=basicdao.insertfeedback(feed_info);
			if(add > 0) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('feedback submited');");
				out.println("</script>");
				request.getRequestDispatcher("index.jsp").forward(request, response);
				
			}else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Feedback not submited');");
				out.println("</script>");
				request.getRequestDispatcher("Feedback.jsp").forward(request, response);
				
			}
		}
		if (action.equalsIgnoreCase("contact")) {
			feedbeen feed_info=new feedbeen();
			feed_info.setName(request.getParameter("name"));
			feed_info.setEmail(request.getParameter("email"));
			feed_info.setSubject(request.getParameter("subject"));
			feed_info.setMsg(request.getParameter("msg"));
			
			int add=basicdao.insertcontact(feed_info);
			if(add > 0) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('contact submited');");
				out.println("</script>");
				request.getRequestDispatcher("index.jsp").forward(request, response);
				
			}else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('contact not submited');");
				out.println("</script>");
				request.getRequestDispatcher("Contactus.jsp").forward(request, response);
				
			}
		}
		if (action.equalsIgnoreCase("update")) {
			RegisterBeen info_update=new RegisterBeen();
			
			info_update.setFirst_name(request.getParameter("fname"));
			info_update.setMiddle_name(request.getParameter("mname"));
			info_update.setLast_name(request.getParameter("lname"));
			info_update.setEmail(request.getParameter("email"));
			info_update.setPhone_number(request.getParameter("phonenumber"));
			info_update.setGender(request.getParameter("gender"));
			info_update.setIs_donor(request.getParameter("donor"));
			info_update.setAddress(request.getParameter("address"));
			info_update.setCity(request.getParameter("city"));
			info_update.setState(request.getParameter("state"));
			info_update.setPincode(Integer.parseInt(request.getParameter("pincode")));
			info_update.setUid(Integer.parseInt(request.getParameter("uid")));
			int update = Logindao.updateuser(info_update);
			if (update > 0) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Update success');");
				out.println("</script>");
				RequestDispatcher rd = request.getRequestDispatcher("Userprofile.jsp");
				rd.include(request, response);
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Update success');");
				out.println("</script>");
				RequestDispatcher rd = request.getRequestDispatcher("Userprofile.jsp");
				rd.include(request, response);
			}
		}
		if(action.equalsIgnoreCase("change password")) 
		  {
			
			  String currentPassword=request.getParameter("current");
			  String Newpass=request.getParameter("new");
				/* String conpass=request.getParameter("confirm"); */
			  Connection conn=datacon.getDatabaseconn();
			  String pass="";
			  String email = null;
			  try {
				  
				  PreparedStatement ps=conn.prepareStatement("select * from user_mst_table where password='"+currentPassword+"'");
				  ResultSet rs=ps.executeQuery();
				  while(rs.next())
				  {
					  email=rs.getString("email");
					  pass=rs.getString("password");
					  } 
				  System.out.println(email+ " "+pass);
					  if(pass.equals(currentPassword))
					  {
					  PreparedStatement ps1=conn.prepareStatement("update user_mst_table set password='"+Newpass+"' where email='"+email+"'");
					  int i=ps1.executeUpdate();
					  out.println("<script type=\"text/javascript\">");
					   out.println("alert('Password Change Successfully');");
					   out.println("</script>");
					   RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
					   rd.include(request, response);
					  ps1.close();
					  conn.close();
					  }
					  else
					  {
					  out.println("<script type=\"text/javascript\">");
					   out.println("alert('something wrong');");
					   out.println("</script>");
					   RequestDispatcher rd=request.getRequestDispatcher("Userprofile.jsp");
					   rd.include(request, response);

					  }
					 }
				  
				  
				
			 catch (Exception e) 
			{
				// TODO: handle exception
			}
			  
			  
			  
		   }		
		
		
		
		
		
		
		
	}

}
