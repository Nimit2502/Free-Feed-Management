package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.been.RegisterBeen;
import com.dataconnn.datacon;

public class registerDao {
	public static int insertregister(RegisterBeen been)  {
		int result = 0;
		Connection conn=datacon.getDatabaseconn();
		String sql = "insert into user_mst_table(first_name,middle_name,last_name,email,password,phone_number,dob,gender,is_donor,address,city,state,pincode,aadhar_no,aadhar_img)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, been.getFirst_name());
			ps.setString(2,been.getMiddle_name());
			ps.setString(3,been.getLast_name());
			ps.setString(4, been.getEmail());
			ps.setString(5,been.getPassword());
			ps.setString(6,been.getPhone_number());
			ps.setString(7,been.getDob());
			ps.setString(8,been.getGender());
			ps.setString(9,been.getIs_donor());
			ps.setString(10,been.getAddress());
			ps.setString(11,been.getCity());
			ps.setString(12,been.getState());
			ps.setInt(13,been.getPincode());
			ps.setString(14,been.getAadhar_no());
			ps.setBlob(15,been.getUimage());
			result=ps.executeUpdate();
		} catch (SQLException  e) {
			// TODO Auto-generated catch block
			System.out.println("done");
		}
		
				
		return result;
	}
	
	public static boolean checkemail(String email)
	{
		boolean flag=false;
		
		
		try {
			Connection conn=datacon.getDatabaseconn();
			String sql = "select * from user_mst_table where email=?";
			PreparedStatement ps;
			ps = conn.prepareStatement(sql);
			ps.setString(1,email);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				flag=true;
			}
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("done");
		}
		return flag;
	}
	
	public static RegisterBeen login(RegisterBeen u)
	{
		RegisterBeen in=null;
		try {
			
			Connection conn=datacon.getDatabaseconn();
			String sql = "select * from user_mst_table where email=? and password=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,u.getEmail());
			ps.setString(2,u.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				in=new RegisterBeen();
				in.setFirst_name(rs.getString("fname"));
				in.setLast_name(rs.getString("lname"));
				in.setEmail(rs.getString("email"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("done");
		}
		return in;
	}
	
	
	public static RegisterBeen log(RegisterBeen u)
	{
		RegisterBeen in=null;
	    try {
			Connection con=datacon.getDatabaseconn();
			String sql="select * from user_mst_table where email=? and password=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,u.getEmail());
			ps.setString(2,u.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				in=new RegisterBeen();
				//in.setid(rs.getInt("id"));
				in.setFirst_name(rs.getString("fname"));
				in.setLast_name(rs.getString("lname"));
				in.setEmail(rs.getString("email"));
				in.setPassword(rs.getString("pass"));
				
				
			}
		} 
	    catch (Exception e) {
	    	System.out.print("sorry jar file issue");
			// TODO: handle exception
		}
		
		return in;
		
	}
	
}
