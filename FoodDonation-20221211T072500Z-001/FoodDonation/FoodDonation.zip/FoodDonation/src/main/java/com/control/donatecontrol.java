package com.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.been.DonationBeen;
import com.dao.DonationDao;

@WebServlet("/donatecontrol")
public class donatecontrol extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String action = request.getParameter("action");
		String error = " ";

		if (action.equalsIgnoreCase("add")) {
			DonationBeen donar_info = new DonationBeen();
			String donar = request.getParameter("donation");

			if (donar.equalsIgnoreCase("volunteer")) {
				donar_info.setFirst_name(request.getParameter("fname"));
				donar_info.setMiddle_name(request.getParameter("mname"));
				donar_info.setLast_name(request.getParameter("lname"));
				donar_info.setPhone_number(request.getParameter("phonenumber"));
				donar_info.setEmail(request.getParameter("email"));
				donar_info.setAddress(request.getParameter("address"));
				donar_info.setCity(request.getParameter("city"));
				donar_info.setState(request.getParameter("state"));
				donar_info.setPincode(Integer.parseInt(request.getParameter("pincode")));
				donar_info.setItemname(request.getParameter("itemname"));
				donar_info.setQuantity(Integer.parseInt(request.getParameter("quantity")));
				donar_info.setIs_donor(request.getParameter("donation"));
				int add=DonationDao.insertvol(donar_info);
				if(add > 0) {
					RequestDispatcher rd = request.getRequestDispatcher("Contactus.jsp");
					rd.include(request, response);
				}else {
					RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
					rd.include(request, response);
				}
				/*
				 * donar_info.setGender(request.getParameter("gender"));
				 * donar_info.setIs_donor(request.getParameter("donation"));
				 */
				
			}else {
				donar_info.setFirst_name(request.getParameter("fname"));
				donar_info.setMiddle_name(request.getParameter("mname"));
				donar_info.setLast_name(request.getParameter("lname"));
				donar_info.setPhone_number(request.getParameter("phonenumber"));
				donar_info.setEmail(request.getParameter("email"));
				donar_info.setAddress(request.getParameter("address"));
				donar_info.setCity(request.getParameter("city"));
				donar_info.setState(request.getParameter("state"));
				donar_info.setPincode(Integer.parseInt(request.getParameter("pincode")));
				donar_info.setItemname(request.getParameter("itemname"));
				donar_info.setQuantity(Integer.parseInt(request.getParameter("quantity")));
				donar_info.setIs_donor(request.getParameter("donation"));
				 int add=DonationDao.insertdonar(donar_info);
				 if(add > 0) {
					 RequestDispatcher rd = request.getRequestDispatcher("Contactus.jsp");
						rd.include(request, response);
				 }else {
					 RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
						rd.include(request, response);
				 }
					
				/*
				 * donar_info.setGender(request.getParameter("gender"));
				 * 
				 */
				
			}
		}
		
		
		
		if (action.equalsIgnoreCase("update")) {
			DonationBeen set = new DonationBeen();
			set.setVolname(request.getParameter("volname"));
			set.setId(Integer.parseInt(request.getParameter("id")));
			
			int update = DonationDao.donerdone(set);
			if (update > 0) {
				RequestDispatcher rd = request.getRequestDispatcher("Donationstatus.jsp");
				rd.include(request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("Viewdonation.jsp");
				rd.include(request, response);
			}
		}
		
	}
	

}
