package com.dataconnn;

import java.sql.Connection;
import java.sql.DriverManager;

public class datacon {
	static Connection conn = null;
	private static final String URL="jdbc:mysql://127.0.0.1:3306/fooddonation?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	private static final String DRIVER="com.mysql.cj.jdbc.Driver";
	private static final String USERNAME="root";
	private static final String PASSWORD="";
	
	public static Connection getDatabaseconn()
	{
		try {
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			return conn;
			
		} catch (Exception e) {
			System.out.println("database.getconnection()error-->"+e.getMessage());
			return null;
		}	
	}
	public static void closeDatabaseconn()
	{
		try {
			conn.close();
		} catch (Exception e) {
			}
	}
}
