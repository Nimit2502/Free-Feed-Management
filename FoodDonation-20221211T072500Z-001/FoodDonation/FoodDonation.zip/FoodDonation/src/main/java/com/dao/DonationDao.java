package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.been.DonationBeen;
import com.been.RegisterBeen;
import com.dataconnn.datacon;
public class DonationDao {
	public static int insertdonar(DonationBeen been) {
		int result=0;
		try {
			Connection conn = datacon.getDatabaseconn();
			String sql = "insert into donation_mst_tbl(`First_Name`, `Middle_Name`, `Last_Name`, `Mobile_Number`, `Email_id`, `Address`, `City_id`, `State_id`, `Pincode`, `item_type`, `item_quantity`,`donar`)values(?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps;
			ps = conn.prepareStatement(sql);
			ps.setString(1, been.getFirst_name());
			ps.setString(2,been.getMiddle_name());
			ps.setString(3,been.getLast_name());
			ps.setString(4,been.getPhone_number());
			ps.setString(5, been.getEmail());
			ps.setString(6,been.getAddress());
			ps.setString(7,been.getCity());
			ps.setString(8,been.getState());
			ps.setInt(9,been.getPincode());
			ps.setString(10,been.getItemname());
			ps.setInt(11,been.getQuantity());
			ps.setString(12,been.getIs_donor());
			ps.executeUpdate();
			
			/*
			 * ps.setString(12,been.getGender()); ps.setString(13,been.getIs_donor());
			 */
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("done");
		}
		return result;
	}
	
	public static int insertvol(DonationBeen been)
	{
		int result=0;
		
		try {
			Connection conn=datacon.getDatabaseconn();
			String sql = "insert into donation_mst_tbl(`First_Name`, `Middle_Name`, `Last_Name`, `Mobile_Number`, `Email_id`, `Address`, `City_id`, `State_id`, `Pincode`, `item_type`, `item_quantity`,`donar`)values(?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps;
			ps = conn.prepareStatement(sql);
			ps.setString(1, been.getFirst_name());
			ps.setString(2,been.getMiddle_name());
			ps.setString(3,been.getLast_name());
			ps.setString(4,been.getPhone_number());
			ps.setString(5, been.getEmail());
			ps.setString(6,been.getAddress());
			ps.setString(7,been.getCity());
			ps.setString(8,been.getState());
			ps.setInt(9,been.getPincode());
			ps.setString(10,been.getItemname());
			ps.setInt(11,been.getQuantity());
			ps.setString(12,been.getIs_donor());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static ResultSet showdonor() throws SQLException {
		ResultSet result = null;

		try {
			Connection con = datacon.getDatabaseconn();
			String sql = "SELECT `Donation_id` , `First_Name`, `Last_Name`, `item_type`, `item_quantity`, `date`,`donar`,`volname`  FROM  donation_mst_tbl where status='pending'";
			PreparedStatement ps = con.prepareStatement(sql);
			result = ps.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public static ResultSet showdonorpending() throws SQLException {
		ResultSet result = null;

		try {
			Connection con = datacon.getDatabaseconn();
			String sql = "SELECT `Donation_id` , `First_Name`, `Last_Name`, `item_type`, `item_quantity`, `date`,`donar`  FROM  donation_mst_tbl where status='apply'";
			PreparedStatement ps = con.prepareStatement(sql);
			result = ps.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public static ResultSet showdonate(RegisterBeen been) throws SQLException {
		
		
		Connection con = datacon.getDatabaseconn();
		String sql = "SELECT `Donation_id` , `First_Name`, `Last_Name`, `item_type`, `item_quantity`, `date`,`donar`  FROM  donation_mst_tbl where status='pending' and Donation_id=?";
		PreparedStatement ps;
		ps = con.prepareStatement(sql);
		ps.setInt(1, been.getUid());
		ResultSet rs = ps.executeQuery();

		return rs;
	}
	
public static ResultSet showdonatesuccess(RegisterBeen been) throws SQLException {
		
		
		Connection con = datacon.getDatabaseconn();
		String sql = "SELECT `Donation_id` , `First_Name`, `Last_Name`, `item_type`, `item_quantity`, `date`,`donar`  FROM  donation_mst_tbl where status='success' and Donation_id=?";
		PreparedStatement ps;
		ps = con.prepareStatement(sql);
		ps.setInt(1, been.getUid());
		ResultSet rs = ps.executeQuery();

		return rs;
	}
	
	/*
	 * public static ResultSet showdonorsuccess() throws SQLException { ResultSet
	 * result = null;
	 * 
	 * try { Connection con = datacon.getDatabaseconn(); String sql =
	 * "SELECT `Donation_id` , `First_Name`, `Last_Name`, `item_type`, `item_quantity`, `date`,`donar`,'volname'  FROM  donation_mst_tbl where status='success'"
	 * ; PreparedStatement ps = con.prepareStatement(sql); result =
	 * ps.executeQuery(); } catch (SQLException e) { e.printStackTrace(); } return
	 * result; }
	 */

public static ResultSet showdonorsuccess() throws SQLException {
	ResultSet result = null;

	try {
		Connection con = datacon.getDatabaseconn();
		String sql = "SELECT `Donation_id` , `First_Name`, `Last_Name`, `item_type`, `item_quantity`, `date`,`donar`,`volname`  FROM  donation_mst_tbl where status='success'";
		PreparedStatement ps = con.prepareStatement(sql);
		result = ps.executeQuery();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return result;
}
	
	
	public static int donerdone(DonationBeen been) {
		int result = 0;
		Connection con = datacon.getDatabaseconn();
		String sql = "update `donation_mst_tbl` set status='success',volname=? where Donation_id=?";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1,been.getVolname());
			ps.setInt(2, been.getId());
			result = ps.executeUpdate();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}
	
}
