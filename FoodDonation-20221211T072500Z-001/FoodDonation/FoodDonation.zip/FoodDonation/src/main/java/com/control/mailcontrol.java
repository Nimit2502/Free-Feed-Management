package com.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.process.mailsend;
import com.dataconnn.*;

@WebServlet("/mailcontrol")
public class mailcontrol extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String action = request.getParameter("action");
		String error = " ";
		if (action.equalsIgnoreCase("send otp")) {
			int min = 100000;
			int max = 999999;
			int otp = 0;
			Random r = new Random();
			otp = r.nextInt(max - min) + min;

			String from = "mscitgroup15@gmail.com";//enter email id
			String to = request.getParameter("email");
			String password = "Devjava123.com";//enter password
			String message = "your otp is:'" + otp + "'";
			String resultMessage = "";
			try {
				Thread.sleep(3000);
				Connection con = datacon.getDatabaseconn();

				PreparedStatement ps = con.prepareStatement("select * from user_mst_table where email='" + to + "'");
				PreparedStatement ps2 = con
						.prepareStatement("update user_mst_table set otp='" + otp + "' where email='" + to + "'");
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					ps2.executeUpdate();
				}

				mailsend.Mailsend(from, password, message, to, resultMessage);
				resultMessage = "The e-mail was sent successfully and account is activated";

				con.close();
			} catch (Exception ex) {
				ex.printStackTrace();
				resultMessage = "There were an error: " + ex.getMessage();
			} finally {

				RequestDispatcher ee = request.getRequestDispatcher("otp.jsp");
				ee.include(request, response);
				out.println("<script type=\"text/javascript\">");
				out.println("alert('" + resultMessage + "');");
				out.println("</script>");

			}
		}
		
		if (action.equalsIgnoreCase("submit otp")) {
			String otp=request.getParameter("otp");
	   		
			try{
				Connection con=datacon.getDatabaseconn();
				PreparedStatement ps=con.prepareStatement("select * from user_mst_table where otp='"+otp+"'");
			    ResultSet rs=ps.executeQuery();
				
			while(rs.next())
			{
				HttpSession session=request.getSession();
				session.setAttribute("rs",otp);
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Your Otp verified Successfully');");
				out.println("</script>");
				RequestDispatcher rd=request.getRequestDispatcher("Reset Password.jsp");
				rd.include(request, response);
				//request.getRequestDispatcher("resetpassword.jsp").forward(request, response);
		
			}
			
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		if(action.equalsIgnoreCase("Reset Password")) {
			
			  String otp=request.getParameter("otp");
		  	  String Newpass=request.getParameter("password");
		  	  String conpass=request.getParameter("conpassword");
		  	  Connection conn=datacon.getDatabaseconn();
		  	  String email = null;
		  	  
		    	try {
			  		  
			  		  PreparedStatement ps=conn.prepareStatement("select * from user_mst_table where otp='"+otp+"'");
			  		  ResultSet rs=ps.executeQuery();
			  		  while(rs.next())
			  		  {
			  			  email=rs.getString("email");
			  		  } 
			  		  System.out.println(email+ " "+otp);
			  			  if(otp.equals(otp))
			  			  {
								/*
								 * PreparedStatement
								 * ps1=conn.prepareStatement("update user_mst_table set password='"
								 * +Newpass+"' , confirmpassword='"+conpass+"' where email='"+email+"'");
								 */
			  				 PreparedStatement ps1=conn.prepareStatement("update user_mst_table set password='"+Newpass+"' where email='"+email+"'");
			  			  int i=ps1.executeUpdate();
			  			  out.println("<script type=\"text/javascript\">");
						  out.println("alert('Password Reset Successfully');");
					      out.println("</script>");
					      RequestDispatcher rd=request.getRequestDispatcher("Login.jsp?message=password change successfully");
						  rd.include(request, response);
			  			 // response.sendRedirect("login.jsp?message=password change successfully"); 			  
			  			  ps1.close();
			  			  conn.close();
			  			  }
			  			  	else
			  			  	{
			  			  		
			  			  		System.out.println("Invalid Current Password");
			  			  	}
			  			 }
			  		catch (Exception e) 
			  	  	{
			  			e.printStackTrace();
			  			// TODO: handle exception
			  	  	}
			}
  
		    }  
		  }  
		  	  
	


