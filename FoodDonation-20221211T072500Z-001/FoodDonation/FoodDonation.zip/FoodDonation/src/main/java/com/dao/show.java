package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dataconnn.datacon;

public class show {
	public static ResultSet countuservol() throws SQLException
	{
		ResultSet result=null;

		try
        {
			Connection con=datacon.getDatabaseconn();
			String sql="SELECT COUNT(`is_donor`) FROM user_mst_table WHERE `is_donor`='volunteer';";
			PreparedStatement ps=con.prepareStatement(sql);
			result =ps.executeQuery();
		} 
		catch (SQLException e) 
		{
				e.printStackTrace();
	    }
		return result;
	}
	
	public static ResultSet countuserdonr() throws SQLException
	{
		ResultSet result=null;

		try
        {
			Connection con=datacon.getDatabaseconn();
			String sql="SELECT COUNT(`is_donor`) FROM user_mst_table WHERE `is_donor`='donor';";
			PreparedStatement ps=con.prepareStatement(sql);
			result =ps.executeQuery();
		} 
		catch (SQLException e) 
		{
				e.printStackTrace();
	    }
		return result;
	}
	
	public static ResultSet countmeal() throws SQLException
	{
		ResultSet result=null;

		try
        {
			Connection con=datacon.getDatabaseconn();
			String sql="select SUM(item_quantity) FROM donation_mst_tbl";
			PreparedStatement ps=con.prepareStatement(sql);
			result =ps.executeQuery();
		} 
		catch (SQLException e) 
		{
				e.printStackTrace();
	    }
		return result;
	}
	
}
