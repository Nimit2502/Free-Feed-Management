package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.been.feedbeen;
import com.dataconnn.datacon;

public class basicdao {
	public static int insertfeedback(feedbeen bn) {
		int result=0;
		try {
			Connection conn = datacon.getDatabaseconn();
			String sql = "insert into feedback_mst_tbl(`Donor_Name`, `Email`, `Donor_comment`, `Ratings`)values(?,?,?,?)";
			PreparedStatement ps;
			ps = conn.prepareStatement(sql);
			ps.setString(1, bn.getName());
			ps.setString(2, bn.getEmail());
			ps.setString(3, bn.getComment());
			ps.setString(4, bn.getRating());
			result=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	public static int insertcontact(feedbeen bn) {
		int result=0;
		try {
			Connection conn = datacon.getDatabaseconn();
			String sql = "insert into contact_mst_tbl(`Name`, `Email`, `subject`, `msg`)values(?,?,?,?)";
			PreparedStatement ps;
			ps = conn.prepareStatement(sql);
			ps.setString(1, bn.getName());
			ps.setString(2, bn.getEmail());
			ps.setString(3, bn.getSubject());
			ps.setString(4, bn.getMsg());
			result=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public static ResultSet showfeedbacks() throws SQLException {
		ResultSet result = null;

		try {
			Connection con =datacon.getDatabaseconn();
			String sql = "SELECT Donor_Name,Email,Donor_comment,Ratings FROM feedback_mst_tbl customer";
			PreparedStatement ps = con.prepareStatement(sql);
			result = ps.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
}
