var fname = document.getElementById("fname");
var emailid = document.getElementById("email");
var subject = document.getElementById("subject");
var message = document.getElementById("message");


function contact() {

    var name_regex = /^[a-z,.'-]+$/i;
    if (fname.value.trim() == '') {
        alert("Name cannot be empty!");
        return false;
    }
    if (!fname.value.match(name_regex))
    {
        alert("Name cannot contain numbers!");
        center_name.focus();
        return false;
    }

    var email_regex = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    var email_regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
   if (!emailid.value.match(email_regex)) {
       alert("Enter your Email address!");
       emailid.focus();
       return false;
   } 
   var name_regex = /^[a-z,.'-]+$/i;
   if (subject.value.trim() == '') {
       alert("Subject cannot be empty!");
       return false;
   }
   var name_regex = /^[a-z,.'-]+$/i;
   if (message.value.trim() == '') {
       alert("Message cannot be empty!");
       return false;
   }
}


