/**
* Template Name: Medilab - v4.7.0
* Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
* Author: BootstrapMade.com
* License: https://bootstrapmade.com/license/
*/
(function() {
  "use strict";

  /**
   * Easy selector helper function
   */
  const select = (el, all = false) => {
    el = el.trim()
    if (all) {
      return [...document.querySelectorAll(el)]
    } else {
      return document.querySelector(el)
    }
  }

  /**
   * Easy event listener function
   */
  const on = (type, el, listener, all = false) => {
    let selectEl = select(el, all)
    if (selectEl) {
      if (all) {
        selectEl.forEach(e => e.addEventListener(type, listener))
      } else {
        selectEl.addEventListener(type, listener)
      }
    }
  }

  /**
   * Easy on scroll event listener 
   */
  const onscroll = (el, listener) => {
    el.addEventListener('scroll', listener)
  }

  /**
   * Navbar links active state on scroll
   */
  let navbarlinks = select('#navbar .scrollto', true)
  const navbarlinksActive = () => {
    let position = window.scrollY + 200
    navbarlinks.forEach(navbarlink => {
      if (!navbarlink.hash) return
      let section = select(navbarlink.hash)
      if (!section) return
      if (position >= section.offsetTop && position <= (section.offsetTop + section.offsetHeight)) {
        navbarlink.classList.add('active')
      } else {
        navbarlink.classList.remove('active')
      }
    })
  }
  window.addEventListener('load', navbarlinksActive)
  onscroll(document, navbarlinksActive)

  /**
   * Scrolls to an element with header offset
   */
  const scrollto = (el) => {
    let header = select('#header')
    let offset = header.offsetHeight

    let elementPos = select(el).offsetTop
    window.scrollTo({
      top: elementPos - offset,
      behavior: 'smooth'
    })
  }

  /**
   * Toggle .header-scrolled class to #header when page is scrolled
   */
  let selectHeader = select('#header')
  let selectTopbar = select('#topbar')
  if (selectHeader) {
    const headerScrolled = () => {
      if (window.scrollY > 100) {
        selectHeader.classList.add('header-scrolled')
        if (selectTopbar) {
          selectTopbar.classList.add('topbar-scrolled')
        }
      } else {
        selectHeader.classList.remove('header-scrolled')
        if (selectTopbar) {
          selectTopbar.classList.remove('topbar-scrolled')
        }
      }
    }
    window.addEventListener('load', headerScrolled)
    onscroll(document, headerScrolled)
  }

  /**
   * Back to top button
   */
  let backtotop = select('.back-to-top')
  if (backtotop) {
    const toggleBacktotop = () => {
      if (window.scrollY > 100) {
        backtotop.classList.add('active')
      } else {
        backtotop.classList.remove('active')
      }
    }
    window.addEventListener('load', toggleBacktotop)
    onscroll(document, toggleBacktotop)
  }

  /**
   * Mobile nav toggle
   */
  on('click', '.mobile-nav-toggle', function(e) {
    select('#navbar').classList.toggle('navbar-mobile')
    this.classList.toggle('bi-list')
    this.classList.toggle('bi-x')
  })

  /**
   * Mobile nav dropdowns activate
   */
  on('click', '.navbar .dropdown > a', function(e) {
    if (select('#navbar').classList.contains('navbar-mobile')) {
      e.preventDefault()
      this.nextElementSibling.classList.toggle('dropdown-active')
    }
  }, true)

  /**
   * Scrool with ofset on links with a class name .scrollto
   */
  on('click', '.scrollto', function(e) {
    if (select(this.hash)) {
      e.preventDefault()

      let navbar = select('#navbar')
      if (navbar.classList.contains('navbar-mobile')) {
        navbar.classList.remove('navbar-mobile')
        let navbarToggle = select('.mobile-nav-toggle')
        navbarToggle.classList.toggle('bi-list')
        navbarToggle.classList.toggle('bi-x')
      }
      scrollto(this.hash)
    }
  }, true)

  /**
   * Scroll with ofset on page load with hash links in the url
   */
  window.addEventListener('load', () => {
    if (window.location.hash) {
      if (select(window.location.hash)) {
        scrollto(window.location.hash)
      }
    }
  });

  /**
   * Preloader
   */
  let preloader = select('#preloader');
  if (preloader) {
    window.addEventListener('load', () => {
      preloader.remove()
    });
  }

  /**
   * Initiate glightbox 
   */
  const glightbox = GLightbox({
    selector: '.glightbox'
  });

  /**
   * Initiate Gallery Lightbox 
   */
  const galelryLightbox = GLightbox({
    selector: '.galelry-lightbox'
  });

  /**
   * Testimonials slider
   */
  new Swiper('.testimonials-slider', {
    speed: 600,
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false
    },
    slidesPerView: 'auto',
    pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
      clickable: true
    },
    breakpoints: {
      320: {
        slidesPerView: 1,
        spaceBetween: 20
      },

      1200: {
        slidesPerView: 2,
        spaceBetween: 20
      }
    }
  });

})()


var f_name = document.getElementById("fname");
var m_name = document.getElementById("mname");
var l_name = document.getElementById("lname");
var emailid = document.getElementById("email");
var contact = document.getElementById("contact");
var pwd = document.getElementById("pwd");
var dob = document.getElementById("dob")
var gender = document.getElementById("gender")
var register = document.getElementById("register")
var pincode = document.getElementById("pincode");
var aadhar = document.getElementById('aadhar');
var img = document.getElementById('center_img');
var address = document.getElementById("address");
var confirm_pwd = document.getElementById("confirmpwd");
var aadhar = document.getElementById("aadharnumber");
var city = document.getElementById("city");
var state = document.getElementById("state");
var itemname = document.getElementById("itemname");
var itemquantity = document.getElementById("itemquantity");
var dateofdonation = document.getElementById("dateofdonation");
var newgender = document.getElementById("newgender");
var registeras = document.getElementById("registeras");

function adddonation() {

	var name_regex = /^[a-z,.'-]+$/i;
	if (gender.value.trim() == '') {
		alert("Select gender!");
		return false;
	}
	if (!f_name.value.match(name_regex)) {
		alert("Name cannot contain numbers!");
		center_name.focus();
		return false;
	}
	if (!m_name.value.match(name_regex)) {
		alert("Middle Name cannot contain numbers!");
		m_name.focus();
		return false;
	}

	if (!city.value) {
		alert("Please Select a city!");
		return false;
	}

	if (l_name.value.trim() == '') {
		alert("Last Name field cannot be empty!");
		return false;
	}
	if (!l_name.value.match(name_regex)) {
		alert("Last Name cannot contain numbers!");
		l_name.focus();
		return false;
	}

	if (dob.value.trim() == '') {
		alert("DOB field cannot be empty!");
		return false;
	}

	if (newgender.value.trim() == '') {
		alert("Please select GENDER!");
		return false;
	}

	if (registeras.value.trim() == '') {
		alert("Please Select Register As option!");
		return false;
	}


	var email_regex = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
	var email_regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if (!emailid.value.match(email_regex)) {
		alert("You have entered an invalid email address!");
		emailid.focus();
		return false;
	}

	var contact_regex = /^(?!.* ).{10}$/;
	if (!contact.value.match(contact_regex)) {
		alert("Incorrect contact number!");
		contact.focus();
		return false;
	}

	if (address.value.trim() == '') {
		alert("Address cannot be empty!");
		return false;
	}

	var max = 300;
	var address_len = address.value.length;
	if (address_len > max) {
		address.value = address.value.substring(0, 300);
		alert("Address cannot be more than 300 characters!");
	}

	if (pincode.value.trim() == '') {
		alert("Pincode cannot be empty!");
		return false;
	}
	var pin_regex = /^(?!.* ).{6}$/;
	if (!pincode.value.match(pin_regex)) {
		alert("Invalid Pincode!");
		pincode.focus();
		return false;
	}

	if (!city.value) {
		alert("Please Select a city!");
		return false;
	}
	if (!state.value) {
		alert("Please Select a state!");
		return false;
	}

	if (aadhar.value.trim() == '') {
		alert("Aadhar number field can not be empty");
		return false;
	}
	aadhar_regex = /^(?!.* ).{12}$/;
	if (!aadhar.value.match(aadhar_regex)) {
		alert("Please check aadhar number!");
		return false;
	}

	if (pwd.value == "") {
		alert("Password cannot be empty!");
		return false;
	}
	var pwd_regex = /(?=^.{8,15}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/;
	if (!pwd.value.match(pwd_regex)) {
		alert('Password must contain at least one number and one uppercase and lowercase letter, and length should be from 8 to 15 characters and cannot contain spaces');
		pwd.focus();
		confirm_pwd.value = "";
		return false;
	}

	if (confirm_pwd == '') {
		alert("Confirm Password field cannot be empty!");
		return false;
	}

	if (pwd.value != confirm_pwd.value) {
		alert("Password doesn't match!");
		return false;
	}


	var aadhar = ["pdf"];
	if (aadhar.value != '') {
		var result = aadhar.includes(certificate_ext);
		if (result == false) {
			alert("Selected file is not a pdf file\nFile format should be pdf");
			return false;
		}
		else {
			if (parseFloat(aadhar.files[0].size / (1024 * 1024)) >= 3) {
				alert("AADHARCARD size should be smaller than 3 MB. \nCurrent file size is " + parseFloat(aadhar.files[0].size / (1024 * 1024)) + "MB");
				return false;

			}
		}
	}
	else {
		alert("No file selected");
		return false;
	}


	var validExt = ["jpeg", "png", "jpg"];
	if (img.value != '') {
		var img_ext = img.value.substring(img.value.lastIndexOf('.') + 1);
		var result = validExt.includes(img_ext);
		if (result == false) {
			alert("Selected file is not an image\nFile format should be jpg/jpeg/png");
			return false;
		}
		else {
			if (parseFloat(img.files[0].size / (1024 * 1024)) >= 3) {
				alert("Image size should be smaller than 3 MB. \nCurrent file size is " + parseFloat(img.files[0].size / (1024 * 1024)) + "MB");
				return false;

			}
		}
	}
	else {
		alert("No image selected");
		return false;
	}




	return true;
}