var f_name = document.getElementById("fname");
var email = document.getElementById("email");

function login() {

    var name_regex = /^[a-z,.'-]+$/i;
    if (fname.value.trim() == '') {
        alert("Name should not be Empty!");
        return false;
    }
   /* if (!f_name.value.match(name_regex))
    {
        alert("Name cannot contain numbers!");
        center_name.focus();
        return false;
    }*/

    return true;

}