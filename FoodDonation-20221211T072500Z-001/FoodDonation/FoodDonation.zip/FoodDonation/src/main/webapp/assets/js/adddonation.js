var f_name = document.getElementById("fname");
var m_name = document.getElementById("mname");
var l_name = document.getElementById("lname");
var emailid = document.getElementById("email");
var contact = document.getElementById("contact");
var pwd = document.getElementById("pwd");
var dob = document.getElementById("dob")
var gender = document.getElementById("gender")
var register = document.getElementById("register")
var pincode = document.getElementById("pincode");
var aadhar = document.getElementById('aadhar');
var img = document.getElementById('center_img');
var address = document.getElementById("address");
var confirm_pwd = document.getElementById("confirmpwd");
var aadhar = document.getElementById("aadharnumber");
var city = document.getElementById("city");
var state = document.getElementById("state");
var itemname = document.getElementById("itemname");
var itemquantity = document.getElementById("itemquantity");
var dateofdonation = document.getElementById("dateofdonation");
var newgender = document.getElementById("newgender");
var registeras = document.getElementById("registeras");

function adddonation() {

	var name_regex = /^[a-z,.'-]+$/i;
	if (gender.value.trim() == '') {
		alert("Select gender!");
		return false;
	}
	if (!f_name.value.match(name_regex)) {
		alert("Name cannot contain numbers!");
		center_name.focus();
		return false;
	}
	if (!m_name.value.match(name_regex)) {
		alert("Middle Name cannot contain numbers!");
		m_name.focus();
		return false;
	}

	if (!city.value) {
		alert("Please Select a city!");
		return false;
	}

	if (l_name.value.trim() == '') {
		alert("Last Name field cannot be empty!");
		return false;
	}
	if (!l_name.value.match(name_regex)) {
		alert("Last Name cannot contain numbers!");
		l_name.focus();
		return false;
	}

	if (dob.value.trim() == '') {
		alert("DOB field cannot be empty!");
		return false;
	}

	if (newgender.value.trim() == '') {
		alert("Please select GENDER!");
		return false;
	}

	if (registeras.value.trim() == '') {
		alert("Please Select Register As option!");
		return false;
	}


	var email_regex = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
	var email_regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if (!emailid.value.match(email_regex)) {
		alert("You have entered an invalid email address!");
		emailid.focus();
		return false;
	}

	var contact_regex = /^(?!.* ).{10}$/;
	if (!contact.value.match(contact_regex)) {
		alert("Incorrect contact number!");
		contact.focus();
		return false;
	}

	if (address.value.trim() == '') {
		alert("Address cannot be empty!");
		return false;
	}

	var max = 300;
	var address_len = address.value.length;
	if (address_len > max) {
		address.value = address.value.substring(0, 300);
		alert("Address cannot be more than 300 characters!");
	}

	if (pincode.value.trim() == '') {
		alert("Pincode cannot be empty!");
		return false;
	}
	var pin_regex = /^(?!.* ).{6}$/;
	if (!pincode.value.match(pin_regex)) {
		alert("Invalid Pincode!");
		pincode.focus();
		return false;
	}

	if (!city.value) {
		alert("Please Select a city!");
		return false;
	}
	if (!state.value) {
		alert("Please Select a state!");
		return false;
	}

	if (aadhar.value.trim() == '') {
		alert("Aadhar number field can not be empty");
		return false;
	}
	aadhar_regex = /^(?!.* ).{12}$/;
	if (!aadhar.value.match(aadhar_regex)) {
		alert("Please check aadhar number!");
		return false;
	}

	if (pwd.value == "") {
		alert("Password cannot be empty!");
		return false;
	}
	var pwd_regex = /(?=^.{8,15}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/;
	if (!pwd.value.match(pwd_regex)) {
		alert('Password must contain at least one number and one uppercase and lowercase letter, and length should be from 8 to 15 characters and cannot contain spaces');
		pwd.focus();
		confirm_pwd.value = "";
		return false;
	}

	if (confirm_pwd == '') {
		alert("Confirm Password field cannot be empty!");
		return false;
	}

	if (pwd.value != confirm_pwd.value) {
		alert("Password doesn't match!");
		return false;
	}


	var aadhar = ["pdf"];
	if (aadhar.value != '') {
		var result = aadhar.includes(certificate_ext);
		if (result == false) {
			alert("Selected file is not a pdf file\nFile format should be pdf");
			return false;
		}
		else {
			if (parseFloat(aadhar.files[0].size / (1024 * 1024)) >= 3) {
				alert("AADHARCARD size should be smaller than 3 MB. \nCurrent file size is " + parseFloat(aadhar.files[0].size / (1024 * 1024)) + "MB");
				return false;

			}
		}
	}
	else {
		alert("No file selected");
		return false;
	}


	var validExt = ["jpeg", "png", "jpg"];
	if (img.value != '') {
		var img_ext = img.value.substring(img.value.lastIndexOf('.') + 1);
		var result = validExt.includes(img_ext);
		if (result == false) {
			alert("Selected file is not an image\nFile format should be jpg/jpeg/png");
			return false;
		}
		else {
			if (parseFloat(img.files[0].size / (1024 * 1024)) >= 3) {
				alert("Image size should be smaller than 3 MB. \nCurrent file size is " + parseFloat(img.files[0].size / (1024 * 1024)) + "MB");
				return false;

			}
		}
	}
	else {
		alert("No image selected");
		return false;
	}




	return true;
}