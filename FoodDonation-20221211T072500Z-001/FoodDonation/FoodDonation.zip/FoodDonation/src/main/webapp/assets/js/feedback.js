var f_name = document.getElementById("fname");
var email = document.getElementById("email");
var yourcomment = document.getElementById("yourcomment");
var ratting = document.getElementById("ratting");


function feedback() {


    var name_regex = /^[a-z,.'-]+$/i;
    if (f_name.value.trim() == '') {
        alert("Name cannot be empty!");
        return false;
    }
    if (!f_name.value.match(name_regex))
    {
        alert("Name cannot contain numbers!");
        center_name.focus();
        return false;
    }

    return true;

}