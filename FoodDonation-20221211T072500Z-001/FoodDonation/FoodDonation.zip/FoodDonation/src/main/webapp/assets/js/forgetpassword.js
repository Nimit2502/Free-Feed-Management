var emailid = document.getElementById("email");
var fname = document.getElementById("fname");

function forgetpassword() {

    var email_regex = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    var email_regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
   if (!email.value.match(email_regex)) {
       alert(" Email cannot be empty!");
       emailid.focus();
       return false;
   } 


   var email_regex = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    var email_regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
   if (!otp.value.match(email_regex)) {
       alert(" OTP cannot be empty!");
       otp.focus();
       return false;
   } 
}